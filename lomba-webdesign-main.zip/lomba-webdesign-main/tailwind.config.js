/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [],
  theme: {
    extend: {
      fontFamily: {
          'manrope': ['Manrope', 'Noto Sans', 'sans-serif'],
          'diphylleia': ['Diphylleia', 'serif'],
      },
      
  }
  },
  plugins: [],
}

